// content.js
const serverUrl = "http://localhost:8080";

console.log("Cookie Extractor content script loaded");

// Immediately let the background script know this content script is loaded
// and request cookie export
chrome.runtime.sendMessage({ action: "contentScriptReady" }, () => {
  // When script loads, request cookies to send to server immediately
  chrome.runtime.sendMessage({ action: "manualExport" }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("Error exporting cookies:", chrome.runtime.lastError);
    } else {
      console.log("Successfully triggered cookie export to server");
    }
  });
});

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Content script received message:", request.action);
  
  if (request.action === "writeCookies") {
    console.log("Received cookies to send to server");
    
    try {
      // Send cookies to the local server
      sendCookiesToServer(request.cookies)
        .then(result => {
          sendResponse({ success: true, method: "server-send" });
        })
        .catch(error => {
          console.error("Error sending cookies to server:", error);
          sendResponse({ success: false, error: error.message });
        });
      
      // Return true to indicate we'll send the response asynchronously
      return true;
    } catch (error) {
      console.error("Error in content script:", error);
      sendResponse({ success: false, error: error.message });
    }
  }
  
  // Return true from the event listener to indicate you wish to send a response asynchronously
  return true;
});

async function sendCookiesToServer(cookieText) {
  const response = await fetch(serverUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain',
      'Accept': 'text/plain',
      'Origin': window.location.origin
    },
    body: cookieText
  });
  
  if (!response.ok) {
    throw new Error(`Server responded with status: ${response.status}`);
  }
  
  const result = await response.text();
  console.log("Server response:", result);
  return result;
}

function directDownload(blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = "cookies.txt";
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  console.log("Direct download initiated");
  return true;
}

function fallbackDownload(blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = "cookies.txt";
  a.click();
  URL.revokeObjectURL(url);
}

async function saveTempFile(blob) {
  const tempPath = await getTempPath();
  const handle = await window.showSaveFilePicker({
    suggestedName: 'cookies.txt',
    types: [{
      description: 'Text Files',
      accept: { 'text/plain': ['.txt'] },
    }],
    startIn: tempPath
  });
  
  const writable = await handle.createWritable();
  await writable.write(blob);
  await writable.close();
  console.log("Cookies saved via File System Access API");
}

// Get temp path - this is a browser compatibility layer
async function getTempPath() {
  // Try to get the temp directory from the system
  // Note: This is limited by browser security, may not work in all cases
  if (window.showDirectoryPicker) {
    try {
      const dirHandle = await window.showDirectoryPicker({ 
        id: 'temp',
        startIn: 'temp' 
      });
      return dirHandle;
    } catch (e) {
      console.log("Could not access temp directory:", e);
      return 'downloads';
    }
  }
  return 'downloads';
} 